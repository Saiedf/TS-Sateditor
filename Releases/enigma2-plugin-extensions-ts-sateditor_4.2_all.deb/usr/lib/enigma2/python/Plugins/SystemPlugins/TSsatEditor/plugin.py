# -*- coding: utf-8 -*-
from __future__ import print_function
from __future__ import division

from . import _
from Components.NimManager import nimmanager
from Plugins.Plugin import PluginDescriptor
from Tools.Directories import fileExists, resolveFilename, SCOPE_PLUGINS
from Screens.Console import Console
from Screens.Standby import TryQuitMainloop
from Screens.MessageBox import MessageBox
from Tools.BoundFunction import boundFunction
from Components.config import config, ConfigSubsection, ConfigYesNo
from Screens.Screen import Screen
from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.MenuList import MenuList
from Components.Button import Button
import os
import time
import shutil
import glob

# ----------- Logging ----------
logfile = "/tmp/tssateditor.log"

# --------- Update Script Path --------
# Modify the path to include the full path to the file.
plugin_path = os.path.dirname(os.path.realpath(__file__))
loadScript = os.path.join(plugin_path, "update-xml-oe.sh")
chmod_done = False

def logMessage(msg):
    """Log messages with timestamp to /tmp/tssateditor.log"""
    try:
        with open(logfile, "a") as f:
            f.write("[%s] %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg))
    except Exception as e:
        print("Failed to write log: %s" % str(e))

def ensureScriptExecutable():
    """Ensure the update script is executable, only once."""
    global chmod_done, loadScript
    if not chmod_done:
        try:
            os.chmod(loadScript, 0o755)
            logMessage("Set execute permission on %s" % loadScript)
            chmod_done = True
        except Exception as e:
            logMessage("Failed to set execute permission: %s" % str(e))

# ----------- Config Setup -----------
if not hasattr(config.misc, "tssateditorT2MI"):
    config.misc.tssateditor = ConfigSubsection()
    config.misc.tssateditorT2MI = ConfigYesNo(default=False)

# ----------- Safe XML File Copy -----------
def copyXmlFiles(src, filename, session):
    """Copy XML files safely to /etc/tuxbox with backup"""
    try:
        dst = "/etc/tuxbox/" + filename
        dst_bak = dst + ".bak"

        # Remove old backup if exists
        if fileExists(dst_bak):
            os.remove(dst_bak)
            logMessage("Removed old backup file: %s" % dst_bak)

        # Rename current file to backup if exists
        if fileExists(dst):
            os.rename(dst, dst_bak)
            logMessage("Renamed %s to %s" % (dst, dst_bak))

        time.sleep(1)  # one Second delay to avoid crash
        shutil.copy2(src, dst)
        logMessage("Successfully copied %s to %s" % (src, dst))
        return True
    except Exception as e:
        logMessage("Error copying %s to %s: %s" % (src, dst, str(e)))
        return False

def cleanBackupFiles():
    """Remove old backup files matching known patterns"""
    try:
        for pattern in [
            "/etc/tuxbox/satellites.xml.backup.*",
            "/etc/tuxbox/terrestrial.xml.backup.*",
            "/etc/tuxbox/cables.xml.backup.*"
        ]:
            for backup_file in glob.glob(pattern):
                os.remove(backup_file)
                logMessage("Removed backup file: %s" % backup_file)
        return True
    except Exception as e:
        logMessage("Error cleaning backup files: %s" % str(e))
        return False

# ----------- General Update Function -----------
def updateXml(session, xml_type, filename, cmd_suffix):
    """General function to update XML files using the script"""
    global loadScript
    logMessage("update %s called" % xml_type)
    ensureScriptExecutable()
    
    # Check for update file
    if not fileExists(loadScript):
        logMessage("Error: Update script not found at %s" % loadScript)
        # Trying to find the file in alternate paths
        alternative_paths = [
            "/usr/lib/enigma2/python/Plugins/SystemPlugins/TSsatEditor/update-xml-oe.sh",
            "/tmp/update-xml-oe.sh",
            "/etc/enigma2/update-xml-oe.sh"
        ]
        
        for alt_path in alternative_paths:
            if fileExists(alt_path):
                loadScript = alt_path
                logMessage("Found update script at alternative path: %s" % alt_path)
                break
        
        # If the file is not found in any of the alternative paths
        if not fileExists(loadScript):
            session.open(MessageBox, "Update script not found!\n\nPlease check if the file exists in one of these locations:\n- %s\n- /usr/lib/enigma2/python/Plugins/SystemPlugins/TSsatEditor/\n- /tmp/\n- /etc/enigma2/" % plugin_path, MessageBox.TYPE_ERROR)
            return
    
    cmd = "%s %s" % (loadScript, cmd_suffix)
    text = "Create user '/etc/enigma2/%s'" % filename
    session.openWithCallback(boundFunction(restartGui, session), Console, text, [cmd])

# ----------- Main Editor Screen -----------
class TSSatEditorScreen(Screen):
    skin = """
    <screen name="TSSatEditorScreen" position="center,center" size="900,680" title=" " flags="wfNoBorder">

        <!-- Header Background -->
        <eLabel position="0,0" size="900,40" backgroundColor="#333333" zPosition="-1" />
        
        <!-- Header Text -->
        <widget name="header_left" position="10,5" size="450,30" font="Regular;28"
            halign="left" valign="center" foregroundColor="#FFFF00" />
        <widget name="header_right" position="460,5" size="430,30" font="Regular;28"
            halign="right" valign="center" foregroundColor="#FFFF00" />

        <!-- Buttons -->
        <widget name="btn_red" position="40,50" size="200,40" font="Regular;26"
            halign="center" valign="center" backgroundColor="red" foregroundColor="white" />
        <widget name="btn_green" position="250,50" size="200,40" font="Regular;26"
            halign="center" valign="center" backgroundColor="green" foregroundColor="black" />
        <widget name="btn_yellow" position="460,50" size="200,40" font="Regular;26"
            halign="center" valign="center" backgroundColor="yellow" foregroundColor="black" />
        <widget name="btn_blue" position="670,50" size="200,40" font="Regular;26"
            halign="center" valign="center" backgroundColor="blue" foregroundColor="white" />

        <!-- Menu -->
        <widget name="menu" position="10,110" size="880,450" font="Regular;30"
            itemHeight="50" scrollbarMode="showOnDemand" />

        <!-- Footer Background -->
        <eLabel position="0,600" size="900,30" backgroundColor="#333333" zPosition="-1" />
        <!-- Footer -->
        <widget name="footer" position="0,600" size="900,30" font="Regular;26"
            halign="center" valign="center" foregroundColor="#FFFF00" />
    </screen>
    """

    def __init__(self, session, menu, callback):
        logMessage("Initializing TSSatEditorScreen")
        Screen.__init__(self, session)

        # Header Labels
        self["header_left"] = Label("TS Satellite Editor Modified By iet5")
        self["header_right"] = Label("VER 4.2")

        # Buttons
        self["btn_red"] = Button(_("Exit"))
        self["btn_green"] = Button(_("Update Satellites"))
        self["btn_yellow"] = Button(_("Update Terrestrial"))
        self["btn_blue"] = Button(_("Update Cables"))

        # Menu
        self.menu = menu
        self["menu"] = MenuList([str(m[0]) for m in menu])
        # Footer Label
        self["footer"] = Label(_("Developed by mfaraj57 ** Modified for Py2 & Py3 by ** iet5"))

        # Callback and closed state
        self.callback = callback
        self._closedAlready = False

        # Actions Mapping
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"],
        {
            "ok": self.okClicked,
            "cancel": self.cancel,
            "red": self.cancel,
            "green": lambda: updateXml(session, "satellites", "satellites.xml", "dvbs"),
            "yellow": lambda: updateXml(session, "terrestrial", "terrestrial.xml", "dvbt"),
            "blue": lambda: updateXml(session, "cables", "cables.xml", "dvbc"),
        }, -1)

    # ------------- Safe Close --------------
    def safeClose(self, result=None):
        """Close the screen safely to avoid multiple closures"""
        if self._closedAlready:
            logMessage("safeClose called but already closed")
            return
        self._closedAlready = True
        logMessage("safeClose executing, result: %s" % str(result))
        self.close(result)
        logMessage("Screen closed successfully.")

    # ------------- Menu OK Click ---------------
    def okClicked(self):
        """Handle OK button on menu"""
        cur = self["menu"].getCurrent()
        logMessage("okClicked called, current: %s" % cur)
        if cur:
            for m in self.menu:
                if m[0] == cur:
                    self.safeClose(m)
                    return
        self.safeClose(None)

    # ----------- Cancel / Exit ---------------
    def cancel(self):
        """Handle cancel, ESC or Red button"""
        logMessage("Cancel triggered (red button / ESC).")
        self.safeClose(None)

# ----------- Additional Functions -----------
def restartGui(session=None):
    """Ask user to restart GUI after update"""
    logMessage("restartGui called")
    if session and not session.nav.getRecordings():
        session.openWithCallback(boundFunction(restartGuiNow, session),
            MessageBox, _("Downloaded successfully\n\nRestart the GUI now?"), MessageBox.TYPE_YESNO, default=False)

def restartGuiNow(session, answer):
    """Perform the actual GUI restart and copy XML files safely"""
    logMessage("restartGuiNow called, answer: %s" % str(answer))
    if answer and session:
        logMessage("Restarting GUI now...")
        for filename in ["satellites.xml", "terrestrial.xml", "cables.xml"]:
           if fileExists("/etc/enigma2/%s" % filename):
                copyXmlFiles("/etc/enigma2/%s" % filename, filename, session)
        cleanBackupFiles()
        logMessage("Waiting 1 second to ensure file copying is complete...")
        time.sleep(1)
        session.open(TryQuitMainloop, 3)

# ----------- Main Function -----------
def SatellitesEditorMain(session, **kwargs):
    """Main menu function to display options and handle user choice"""
    menu = []
    logMessage("SatellitesEditorMain called")
    text = _("Select action:")

    # DVB-S Options
    if fileExists('/etc/enigma2/satellites.xml'):
        menu.append((_("Open user '/etc/enigma2/satellites.xml'"), "openedit"))
        menu.append((_("Disable user '/etc/enigma2/satellites.xml'"), "disable"))
        menu.append((_("Remove user '/etc/enigma2/satellites.xml'"), "remove"))
    else:
        if not fileExists('/etc/enigma2/satellites.xml.disabled'):
            menu.append((_("Create user '/etc/enigma2/satellites.xml'"), "create"))
            menu.append((_("Create user '/etc/enigma2/satellites.xml' (use default)"), "createdefault"))
        else:
            menu.append((_("Enable user '/etc/enigma2/satellites.xml'"), "enable"))

    # T2MI Option
    menu.append((_("Use TSID/ONID")
    if config.misc.tssateditorT2MI.value else _("Use T2MI PLP"), "t2mi"))

    # DVB-T Options
    if nimmanager.hasNimType('DVB-T'):
        menu.append((_("Remove user '/etc/enigma2/terrestrial.xml'")
        if fileExists('/etc/enigma2/terrestrial.xml')
        else _("Create user '/etc/enigma2/terrestrial.xml'"), "dvbt"))

    # DVB-C Options
    if nimmanager.hasNimType('DVB-C'):
        menu.append((_("Remove user '/etc/enigma2/cables.xml'")
        if fileExists('/etc/enigma2/cables.xml')
        else _("Create user '/etc/enigma2/cables.xml'"), "dvbc"))

    # ------- Handle Menu Selection --------------
    if menu:
        def boxAction(choice):
            logMessage("boxAction called with choice: %s" % str(choice))
            if choice is None:
                logMessage("User exited without selection")
                return

            # DVB-S Options
            if choice[1] == "openedit":
                logMessage("Opening satellites.xml in editor")
                from .satedit import SatellitesEditor
                session.openWithCallback(boundFunction(restartGui, session), SatellitesEditor)

            elif choice[1] == "disable":
                logMessage("Disabling satellites.xml")
                if fileExists("/etc/enigma2/satellites.xml"):
                    os.rename("/etc/enigma2/satellites.xml", "/etc/enigma2/satellites.xml.disabled")

            elif choice[1] == "remove":
                logMessage("Removing satellites.xml")
                def removeFile(answer, filepath="/etc/enigma2/satellites.xml"):
                    if answer and fileExists(filepath):
                        try:
                            os.remove(filepath)
                            logMessage("%s removed successfully" % filepath)
                        except Exception as e:
                            logMessage("Failed to remove %s: %s" % (filepath, str(e)))
                session.openWithCallback(removeFile, MessageBox,
                    _("Do you really want to remove satellites.xml?"), MessageBox.TYPE_YESNO, default=False)

            elif choice[1] == "enable":
                logMessage("Enabling satellites.xml")
                if fileExists("/etc/enigma2/satellites.xml.disabled"):
                    os.rename("/etc/enigma2/satellites.xml.disabled", "/etc/enigma2/satellites.xml")

            elif choice[1] == "createdefault":
                logMessage("Creating satellites.xml from default tuxbox copy")
                if fileExists("/etc/tuxbox/satellites.xml"):
                    shutil.copy2("/etc/tuxbox/satellites.xml", "/etc/enigma2/satellites.xml")

            elif choice[1] == "create":
                logMessage("Creating satellites.xml")
                updateXml(session, "satellites", "satellites.xml", "dvbs")

            # DVB-T & DVB-C
            elif choice[1] in ["dvbt", "dvbc"]:
                xml_map = {
                    "dvbt": ("terrestrial.xml", "dvbt"),
                    "dvbc": ("cables.xml", "dvbc")
                }
                filename, cmd_suffix = xml_map[choice[1]]
                action = _("Remove user '/etc/enigma2/%s'" % filename) if fileExists("/etc/enigma2/%s" % filename) else _("Create user '/etc/enigma2/%s'" % filename)
                if "Remove" in action:
                    logMessage("Removing %s" % filename)
                    def removeXml(answer, filepath="/etc/enigma2/%s" % filename):
                        if answer and fileExists(filepath):
                            try:
                                os.remove(filepath)
                                logMessage("%s removed successfully" % filepath)
                            except Exception as e:
                                logMessage("Failed to remove %s: %s" % (filepath, str(e)))
                    session.openWithCallback(removeXml, MessageBox,
                        _("Do you really want to remove %s?" % filename), MessageBox.TYPE_YESNO, default=False)
                else:
                    logMessage("Creating %s" % filename)
                    updateXml(session, filename.split(".")[0], filename, cmd_suffix)

            # T2MI Option
            elif choice[1] == "t2mi":
                config.misc.tssateditorT2MI.value = not config.misc.tssateditorT2MI.value
                config.misc.tssateditorT2MI.save()
                logMessage("T2MI mode switched to: %s" % str(config.misc.tssateditorT2MI.value))
                # Refresh menu after T2MI switch
                session.openWithCallback(boxAction, TSSatEditorScreen, menu, boxAction)

        # Open screen
        session.openWithCallback(boxAction, TSSatEditorScreen, menu, boxAction)

# ----------- Startup plugin -----------
def SatellitesEditorStart(menuid, **kwargs):
    if menuid == 'scan':
        return [(_('TS-Satellites Editor'), SatellitesEditorMain, 'sat_editor', None)]
    return []

def Plugins(**kwargs):
    if nimmanager.hasNimType('DVB-S'):
        return [PluginDescriptor(
            name=_("TS-Satellites Editor"),
            description=_("User satellites.xml"),
            where=PluginDescriptor.WHERE_MENU,
            fnc=SatellitesEditorStart
        )]
    return []